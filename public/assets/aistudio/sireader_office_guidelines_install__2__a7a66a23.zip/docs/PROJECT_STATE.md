# SIREADER Virtual Office — Project State

## Current phase
Phase 1 — futuristic isometric 3D virtual office, interactive characters.

## Product decisions
- Frontend stays separate from the Python backend in `C:\SIREADER\office-ui`.
- Visual direction: futuristic.
- Camera: isometric.
- Interaction: clickable workers/workstations and interactive UI.
- Initial team: 7 workers (Supervisor, Haiku, Sonnet, Opus, Decision Engineer, Market Monitor, Data Archivist).
- Initial UI uses mock data/local state only.
- No MT5, trading execution, Telegram, Supabase, or live AI provider connections in Phase 1.

## Architecture constraints
- Frontend target: React 19, TypeScript, Vite, Three.js, React Three Fiber v9, compatible stable Drei.
- Keep worker definitions, office layout, workstation placement, UI panels, and avatar animation modular/data-driven.
- Design data structures so the team can grow beyond the initial 7 workers.
- Never modify Python backend files, migrations, `.env`, credentials, Telegram, MT5, or trading execution while building Phase 1.

## Current implementation status
- A Phase 1 starter ZIP was generated separately in this conversation.
- Local extraction, dependency installation, browser preview, and production build have NOT yet been verified.
- Skill Pack and this state file are provided as project guidance; they do not indicate that the UI is already integrated with the backend.

## Known limitations
- Worker activity is simulated until a later approved backend-integration phase.
- Character quality depends on suitable licensed rigged GLB/glTF assets and animation clips.

## Next tasks
1. Confirm the starter app exists in `office-ui` and inspect its files.
2. Install dependencies and run the local development server.
3. Verify `npm run build` and fix any errors.
4. Improve the office scene, 7 worker avatars, and interactions in small, testable steps.
5. Update this file after each milestone. Never add secrets here.

## Last verified checks
- Backend SIREADER previously reported 329 passing tests; these do not verify the frontend.
- Frontend build has not yet been verified locally.
