# Google AI Studio — Initial Build Prompt

Build **SIREADER Virtual Office**, a desktop-first futuristic 3D isometric virtual office inhabited by seven human-like AI worker avatars.

First read and obey the complete `AI_RULES.md` included with this prompt. Treat it as persistent project instructions. If the file is not present in the workspace yet, use the rules pasted in the prompt context and create `AI_RULES.md` in the project root.

## Visual concept
Create a cohesive, premium sci-fi corporate office with an isometric/orthographic camera, dark architectural materials, glass partitions, cyan/blue/violet accent lighting, readable room labels, desks, computers, and a central reception. Make it feel like a small explorable management-simulation game, not a conventional flat dashboard with a 3D background.

## Initial rooms and workers
1. Reception / Supervisor — routes tasks and oversees the office.
2. Research Room / Haiku — message classification and extraction (simulation only).
3. Analysis Room / Sonnet — context and reasoning (simulation only).
4. Strategy Room / Opus — complex escalation (simulation only).
5. Trading Operations / Decision Engineer — deterministic decision checks (simulation only).
6. Market Monitoring / Market Monitor — price/spread watch simulation only.
7. Archive Room / Data Archivist — evidence and history simulation only.

## Human avatars
Use a reusable rigged-avatar component and a data-driven worker registry. Prefer properly licensed GLB/glTF human avatars with suitable idle, seated, typing, walking, and talking clips. If the assets are not available, create a clearly marked temporary placeholder and provide an asset integration plan; do not claim primitive shapes are finished characters. Give workers distinct clothing/color accents and individual desk locations.

## Interactions
- Click each avatar or desk to open a profile panel.
- Show worker identity, role, department, current task, status, activity log, and simulated token/cost counters.
- Add working controls for assigning a mock task, pause/resume, and activity history.
- Provide a live simulated task feed.
- Character pose/animation must respond to worker state.
- Add camera pan, zoom, and reset controls while keeping isometric view as default.

## Technical implementation
Use React 19, TypeScript, Vite, Three.js, React Three Fiber v9, and a stable compatible Drei release. Build reusable components, typed data, and clean separation between scene, worker registry, simulation service, and overlay UI. Avoid a monolithic component.

## Phase 1 scope restrictions
This is a frontend-only prototype with mock data. Do not connect to Python, MT5, Telegram, Supabase, Claude, Gemini API, or any external backend. Do not add order execution, secrets, `.env`, or authentication.

## Build sequence
1. Inspect and explain a short implementation plan.
2. Create the application shell and camera/lighting.
3. Create the complete office layout and seven labeled rooms/workstations.
4. Add worker avatars/placeholders and state-driven animations.
5. Add selection, worker panel, controls, and activity feed.
6. Add responsive fallback UI and performance controls.
7. Run typecheck and production build; fix errors.
8. Summarize created files, build result, external assets still needed, and limitations.

Prioritize a coherent, visually polished office and working interactions over extra features. Do not claim human animation is complete unless actual rigged assets and animation clips work in preview.
