# SIREADER Virtual Office — AI Developer Skill Pack

Paket panduan proyek untuk membangun SIREADER Virtual Office dengan Google AI Studio Build Mode.

> Ini bukan plugin atau extension yang dipasang ke Google AI Studio. Google AI Studio Build belum menyediakan mekanisme instalasi Skill Pack seperti Hermes. File Markdown ini berfungsi sebagai project playbook/context untuk mengarahkan Gemini saat membuat dan mengubah aplikasi.

## Isi paket

- `CORE_RULES_COMPACT.md` — aturan inti ringkas untuk Custom Instructions agar konteks tidak boros.
- `AI_RULES.md` — aturan proyek lengkap, simpan sebagai dokumentasi project dan rujuk saat audit/perubahan besar.
- `START_PROMPT.md` — prompt awal untuk memulai Build Mode.
- `skills/01-software-architecture.md` — arsitektur React, komponen, dan struktur file.
- `skills/02-threejs-r3f.md` — Three.js dan React Three Fiber.
- `skills/03-virtual-office-design.md` — desain kantor futuristik isometrik.
- `skills/04-characters-animation.md` — karakter manusia, rig, GLB, dan animasi.
- `skills/05-interaction-state.md` — klik, task, state worker, dan simulasi.
- `skills/06-ui-ux.md` — panel, hierarki informasi, dan interaksi UI.
- `skills/07-performance.md` — FPS, rendering, asset, dan optimasi.
- `skills/08-testing-debugging.md` — build, test, regression, dan pelaporan.
- `skills/09-backend-integration.md` — kontrak integrasi Python untuk fase berikutnya; belum diaktifkan pada Fase 1.
- `skills/10-assets-security.md` — lisensi aset, keamanan, dan larangan memasukkan secret.
- `skills/11-token-efficiency.md` — cara kerja hemat konteks/token tanpa mengorbankan kualitas.

## Cara memasang di Google AI Studio Build Mode

Penting: folder yang diekstrak ke `C:\SIREADER\office-ui\project-guidelines` hanya tersimpan di komputer lokal. AI Studio yang berjalan di browser tidak otomatis bisa membaca folder C: tersebut. Jangan menganggap ekstraksi ZIP lokal sama dengan memasang skill ke AI Studio.

1. Buka https://aistudio.google.com/ → **Build** → **New App** → pilih Web App.
2. Buka ikon Settings/gear pada aplikasi, cari **System instructions / Custom instructions**. Tempel isi `CORE_RULES_COMPACT.md` ke kolom tersebut. Custom Instructions tersedia di pengaturan aplikasi Build menurut panduan Google Codelab.
3. Di kolom prompt, tempel isi `START_PROMPT.md` untuk memulai pembangunan.
4. Setelah Gemini membuat project, kirim prompt untuk membuat `AI_RULES.md`, `docs/PROJECT_STATE.md`, dan folder `docs/skills/` di workspace project. Berikan isi dokumen lengkap dengan cara menempelkan file yang relevan saat dibutuhkan.
5. Jangan tempel semua 11 skill sekaligus. Saat membuat karakter, berikan `04-characters-animation.md`; saat optimasi, berikan `07-performance.md`; saat debugging, berikan `08-testing-debugging.md`; saat mengatur alur kerja agent, berikan `11-token-efficiency.md`.
6. Jika suatu saat panel **Add files (+)** pada Build Mode menawarkan upload file lokal, kamu boleh melampirkan Markdown yang relevan. Dokumentasi Build Mode juga menjelaskan opsi Import from GitHub; kita tidak menggunakan jalur itu karena project ini dijaga lokal tanpa GitHub.
7. Setelah hasil awal sesuai, ekspor project ZIP dari AI Studio. Ekstrak ke folder staging lokal, misalnya `C:\SIREADER\office-ui-ai-studio-export\`. Bandingkan dan jalankan build sebelum mengganti project lokal.

### Custom Instructions ringkas untuk menghemat konteks

Pakai `CORE_RULES_COMPACT.md`, bukan seluruh `AI_RULES.md` dan 11 skill. Aturan inti dipakai terus-menerus; skill rinci hanya diberikan ketika tugas membutuhkannya. Instruksi yang lebih pendek mengurangi konteks berulang, tetapi tidak menambah kuota akun atau mengubah batas penggunaan Google.

### Prompt untuk menyimpan panduan ke project

Setelah aplikasi awal dibuat, tempel prompt berikut:

```text
Buat file AI_RULES.md, docs/PROJECT_STATE.md, dan folder docs/skills/ di root project. Saya akan memberikan isi panduan yang relevan pada pesan berikutnya. Simpan dokumen yang saya berikan tanpa mengubah makna teknisnya. Jangan ubah source code aplikasi pada tugas ini. PROJECT_STATE.md harus ringkas (maksimal sekitar 200 kata), berisi fase saat ini, fitur yang sudah bekerja, keputusan arsitektur, masalah yang diketahui, hasil build/test terakhir, dan tugas berikutnya. Jangan menyimpan secret. Tampilkan daftar file yang dibuat.
```

### Aturan hemat token

- `CORE_RULES_COMPACT.md` untuk instruksi permanen.
- `AI_RULES.md` untuk referensi lengkap, bukan ditempel setiap kali.
- Satu atau dua skill sesuai pekerjaan saat itu.
- Simpan keputusan dan status proyek di `docs/PROJECT_STATE.md`; saat sesi baru, berikan file ini daripada mengulang seluruh riwayat chat.
- Minta perubahan kecil dan terukur; jalankan test/build yang relevan. Jangan mengorbankan verifikasi demi menghemat token.

## Referensi resmi

- Google AI Studio Build Mode: https://ai.google.dev/gemini-api/docs/aistudio-build-mode
- React Three Fiber introduction: https://r3f.docs.pmnd.rs/getting-started/introduction
- React Three Fiber installation: https://r3f.docs.pmnd.rs/getting-started/installation
- Three.js installation manual: https://threejs.org/manual/#en/installation
- Khronos glTF Blender exporter: https://docs.blender.org/manual/en/latest/addons/import_export/scene_gltf2.html
- Khronos glTF project: https://github.com/KhronosGroup/glTF

## Prinsip penting

- `C:\SIREADER\app` adalah backend Python utama. Jangan ubah dari project frontend.
- Fase 1 menggunakan mock data dan local state.
- Tidak ada koneksi MT5, Supabase, Telegram, atau AI API pada Fase 1.
- Tidak ada order execution.
- Jangan masukkan `.env`, API key, token bot, password, atau `DATABASE_URL` ke project frontend/prompt.
- Gunakan React Three Fiber v9 dengan React 19; jangan pasang R3F v8 untuk React 19 atau versi v10 alpha untuk proyek stabil ini.
- Gunakan komponen modular dan data-driven agar worker dapat bertambah dari 7 ke 50–100 tanpa menyalin komponen karakter satu per satu.
